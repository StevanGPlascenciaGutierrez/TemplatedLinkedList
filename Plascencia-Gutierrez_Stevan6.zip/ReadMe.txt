Run make.
Have a great summer :)
